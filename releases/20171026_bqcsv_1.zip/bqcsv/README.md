# bqcsv
wxPython application to manipulate comma separated value (CSV) files

This application requires wxPython to be installed. Please see the following link: https://www.wxpython.org/pages/downloads/

